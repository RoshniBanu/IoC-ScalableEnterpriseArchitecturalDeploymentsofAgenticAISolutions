import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(2000) }))
    .min(1)
    .max(20),
});

export const askOfficeAssist = createServerFn({ method: "POST" })
  .inputValidator((d) => schema.parse(d))
  .handler(async ({ data }) => {
    const { runOfficeAssistAgent } = await import("@/agent/officeAssistAgent.server");
    try {
      const r = await runOfficeAssistAgent(data.messages);
      return { ok: true as const, ...r };
    } catch (e) {
      console.error("OfficeAssist agent error", e);
      return { ok: false as const, text: "", toolUsed: false };
    }
  });
