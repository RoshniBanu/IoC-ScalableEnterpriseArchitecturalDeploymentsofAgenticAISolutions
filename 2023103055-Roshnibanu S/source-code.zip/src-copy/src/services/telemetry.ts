import { useEffect, useState } from "react";

// Demo/application telemetry, stored in this browser only.
export interface ActivityRecord {
  id: string;
  timestamp: number;
  request: string;
  toolUsed: boolean;
  status: "success" | "failed";
  responseMs: number;
}

const KEY = "officeassist-telemetry";
const EVENT = "officeassist-telemetry-change";

export function readActivity(): ActivityRecord[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function recordActivity(r: Omit<ActivityRecord, "id">) {
  const list = [{ ...r, id: crypto.randomUUID() }, ...readActivity()].slice(0, 200);
  localStorage.setItem(KEY, JSON.stringify(list));
  window.dispatchEvent(new Event(EVENT));
}

export function clearActivity() {
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event(EVENT));
}

export function useActivity() {
  const [list, setList] = useState<ActivityRecord[]>([]);
  useEffect(() => {
    const sync = () => setList(readActivity());
    sync();
    window.addEventListener(EVENT, sync);
    return () => window.removeEventListener(EVENT, sync);
  }, []);
  return list;
}
