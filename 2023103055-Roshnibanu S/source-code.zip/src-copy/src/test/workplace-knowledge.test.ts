import { describe, expect, it } from "vitest";
import { searchWorkplaceKnowledge } from "@/tools/workplaceKnowledgeTool";

describe("Workplace Knowledge Tool", () => {
  it("WFH allows up to 2 days per week", () => {
    expect(searchWorkplaceKnowledge("work from home policy")[0]?.content).toContain("2 days per week");
  });
  it("office hours are 9 to 6, Mon-Fri", () => {
    expect(searchWorkplaceKnowledge("office working hours")[0]?.content).toContain("9:00 AM to 6:00 PM, Monday to Friday");
  });
  it("planned leave needs 2 working days notice", () => {
    expect(searchWorkplaceKnowledge("leave policy")[0]?.content).toContain("2 working days in advance");
  });
  it("returns nothing for unknown topics", () => {
    expect(searchWorkplaceKnowledge("parking allowance")).toHaveLength(0);
  });
});
