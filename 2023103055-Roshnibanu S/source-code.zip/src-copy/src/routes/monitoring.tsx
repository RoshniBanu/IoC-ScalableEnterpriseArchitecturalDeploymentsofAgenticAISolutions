import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { clearActivity, useActivity } from "@/services/telemetry";

export const Route = createFileRoute("/monitoring")({
  head: () => ({
    meta: [
      { title: "Agent Monitoring — OfficeAssist" },
      { name: "description", content: "Monitor OfficeAssist Agent requests, tool calls and response times." },
      { property: "og:title", content: "Agent Monitoring — OfficeAssist" },
      { property: "og:description", content: "Requests, Workplace Knowledge Tool calls and response times." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MonitoringPage,
});

function MonitoringPage() {
  const list = useActivity();
  const ok = list.filter((a) => a.status === "success").length;
  const avg = list.length ? Math.round(list.reduce((s, a) => s + a.responseMs, 0) / list.length) : 0;
  const stats = [
    ["Total Agent Requests", list.length],
    ["Successful Requests", ok],
    ["Failed Requests", list.length - ok],
    ["Average Response Time", list.length ? `${(avg / 1000).toFixed(1)}s` : "—"],
    ["Workplace Knowledge Tool Calls", list.filter((a) => a.toolUsed).length],
  ] as const;

  return (
    <AppShell>
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-6 py-4">
        <div>
          <h1 className="font-display text-xl font-semibold text-foreground">Agent Monitoring</h1>
          <p className="text-sm text-muted-foreground">Application telemetry recorded in this browser</p>
        </div>
        {list.length > 0 && <Button variant="outline" size="sm" onClick={clearActivity}>Clear activity</Button>}
      </header>
      <div className="space-y-6 p-6">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {stats.map(([label, value]) => (
            <div key={label} className="rounded-lg border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="mt-2 font-display text-2xl font-semibold text-card-foreground">{value}</p>
            </div>
          ))}
        </div>
        <section className="rounded-lg border border-border bg-card">
          <h2 className="border-b border-border px-4 py-3 text-sm font-medium text-card-foreground">Recent activity</h2>
          {list.length === 0 ? (
            <p className="px-4 py-10 text-center text-sm text-muted-foreground">No agent activity yet. Ask the assistant a question to see it here.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-xs text-muted-foreground">
                  <tr>{["Timestamp", "User request", "Tool used", "Status", "Response time"].map((h) => <th key={h} className="px-4 py-2 font-medium">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {list.slice(0, 25).map((a) => (
                    <tr key={a.id} className="border-t border-border">
                      <td className="whitespace-nowrap px-4 py-2.5 text-muted-foreground">{new Date(a.timestamp).toLocaleString()}</td>
                      <td className="max-w-xs truncate px-4 py-2.5 text-card-foreground">{a.request}</td>
                      <td className="whitespace-nowrap px-4 py-2.5 text-card-foreground">{a.toolUsed ? "Workplace Knowledge Tool" : "None"}</td>
                      <td className="px-4 py-2.5">
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${a.status === "success" ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}>
                          {a.status === "success" ? "Success" : "Failed"}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-2.5 text-muted-foreground">{(a.responseMs / 1000).toFixed(1)}s</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </AppShell>
  );
}
