import { createFileRoute } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — OfficeAssist" },
      { name: "description", content: "Manage your OfficeAssist profile, notifications, assistant preferences and security." },
      { property: "og:title", content: "Settings — OfficeAssist" },
      { property: "og:description", content: "Profile, notifications, assistant preferences and security." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function Section({ title, desc, children }: { title: string; desc: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-border bg-card p-5">
      <h2 className="font-medium text-card-foreground">{title}</h2>
      <p className="mb-4 text-sm text-muted-foreground">{desc}</p>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Toggle({ id, label, on }: { id: string; label: string; on?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <Label htmlFor={id} className="font-normal">{label}</Label>
      <Switch id={id} defaultChecked={!!on} />
    </div>
  );
}

function SettingsPage() {
  return (
    <AppShell>
      <header className="border-b border-border px-6 py-4">
        <h1 className="font-display text-xl font-semibold text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">Manage your OfficeAssist preferences</p>
      </header>
      <div className="mx-auto w-full max-w-2xl space-y-4 p-6">
        <Section title="Profile" desc="Your demo employee details.">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5"><Label htmlFor="name">Name</Label><Input id="name" defaultValue="Demo Employee" /></div>
            <div className="space-y-1.5"><Label htmlFor="email">Email</Label><Input id="email" type="email" defaultValue="employee@example.com" /></div>
          </div>
        </Section>
        <Section title="Notifications" desc="Choose what you hear about.">
          <Toggle id="n1" label="Policy update announcements" on />
          <Toggle id="n2" label="Weekly workplace digest" />
        </Section>
        <Section title="Assistant Preferences" desc="Tune how OfficeAssist responds.">
          <Toggle id="p1" label="Show agent activity status" on />
          <Toggle id="p2" label="Prefer concise answers" on />
        </Section>
        <Section title="Security" desc="Keep your account safe.">
          <Toggle id="s1" label="Two-factor authentication" />
          <Toggle id="s2" label="Sign out on inactivity" on />
        </Section>
        <div className="flex justify-end"><Button onClick={() => toast.success("Settings saved")}>Save changes</Button></div>
      </div>
    </AppShell>
  );
}
