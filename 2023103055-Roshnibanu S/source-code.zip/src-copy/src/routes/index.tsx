import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowUp, Bot, BookOpen, Loader2, User } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { askOfficeAssist } from "@/services/agent.functions";
import { recordActivity } from "@/services/telemetry";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OfficeAssist — Your intelligent workplace assistant" },
      { name: "description", content: "Ask OfficeAssist about workplace policies, office hours, leave and employee benefits." },
      { property: "og:title", content: "OfficeAssist — Your intelligent workplace assistant" },
      { property: "og:description", content: "Find workplace policies, guidelines and employee information instantly." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AssistantPage,
});

const SUGGESTIONS = [
  "What is the work-from-home policy?",
  "What are the office working hours?",
  "What is the leave policy?",
  "What employee benefits are available?",
  "What are the general workplace guidelines?",
];
const ERROR_TEXT = "Sorry, I couldn't process that request right now. Please try again.";

interface Msg {
  role: "user" | "assistant";
  content: string;
  toolUsed?: boolean;
  error?: boolean;
}

function AssistantPage() {
  const ask = useServerFn(askOfficeAssist);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  async function send(text: string) {
    const q = text.trim().slice(0, 2000);
    if (!q || busy) return;
    const next = [...messages, { role: "user" as const, content: q }];
    setMessages(next);
    setInput("");
    setBusy(true);
    const start = performance.now();
    const history = next.filter((m) => !m.error).slice(-10).map(({ role, content }) => ({ role, content }));
    let ok = false;
    let toolUsed = false;
    try {
      const r = await ask({ data: { messages: history } });
      ok = r.ok;
      toolUsed = r.toolUsed;
      setMessages((m) => [...m, r.ok ? { role: "assistant", content: r.text, toolUsed } : { role: "assistant", content: ERROR_TEXT, error: true }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: ERROR_TEXT, error: true }]);
    } finally {
      recordActivity({ timestamp: Date.now(), request: q, toolUsed, status: ok ? "success" : "failed", responseMs: Math.round(performance.now() - start) });
      setBusy(false);
    }
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    send(input);
  }

  return (
    <AppShell>
      <header className="border-b border-border px-6 py-4">
        <h1 className="font-display text-xl font-semibold text-foreground">OfficeAssist</h1>
        <p className="text-sm text-muted-foreground">Your intelligent workplace assistant</p>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-6 md:px-8">
        <div className="mx-auto flex max-w-3xl flex-col gap-5">
          {messages.length === 0 && (
            <div className="animate-in fade-in py-8 text-center duration-500">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-primary">
                <Bot className="h-6 w-6" />
              </div>
              <p className="mx-auto max-w-md text-foreground">
                Welcome to OfficeAssist. I can help you find workplace policies, guidelines and employee information.
              </p>
              <div className="mx-auto mt-6 grid max-w-xl gap-2 sm:grid-cols-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="rounded-lg border border-border bg-card px-4 py-3 text-left text-sm text-card-foreground transition-colors hover:border-primary/40 hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={`animate-in fade-in slide-in-from-bottom-1 flex gap-3 duration-300 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
              <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${m.role === "user" ? "bg-secondary text-secondary-foreground" : "bg-primary text-primary-foreground"}`}>
                {m.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>
              <div className={`max-w-[80%] ${m.role === "user" ? "text-right" : ""}`}>
                <div
                  className={`whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-left text-sm leading-relaxed ${
                    m.role === "user" ? "bg-primary text-primary-foreground" : m.error ? "border border-destructive/30 bg-destructive/5 text-destructive" : "border border-border bg-card text-card-foreground"
                  }`}
                >
                  {m.content}
                </div>
                {m.role === "assistant" && !m.error && (
                  <p className="mt-1.5 flex items-center gap-1 text-xs text-muted-foreground">
                    {m.toolUsed && <BookOpen className="h-3 w-3" />}
                    {m.toolUsed ? "OfficeAssist Agent • Workplace Knowledge Tool" : "OfficeAssist Agent"}
                  </p>
                )}
              </div>
            </div>
          ))}

          {busy && <AgentStatus />}
          <div ref={endRef} />
        </div>
      </div>

      <form onSubmit={onSubmit} className="border-t border-border bg-background px-4 py-4 md:px-8">
        <div className="mx-auto flex max-w-3xl items-end gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(input);
              }
            }}
            maxLength={2000}
            rows={1}
            placeholder="Ask about workplace policies, hours, leave or benefits..."
            aria-label="Message OfficeAssist"
            className="max-h-40 min-h-11 resize-none"
          />
          <Button type="submit" size="icon" disabled={busy || !input.trim()} aria-label="Send message" className="h-11 w-11 shrink-0">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
          </Button>
        </div>
      </form>
    </AppShell>
  );
}

function AgentStatus() {
  const [phase, setPhase] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setPhase(1), 1500);
    return () => clearTimeout(t);
  }, []);
  return (
    <div className="flex items-center gap-2 pl-11 text-sm text-muted-foreground" role="status">
      <Loader2 className="h-3.5 w-3.5 animate-spin" />
      {phase === 0 ? "OfficeAssist Agent is analyzing your request..." : "Searching workplace knowledge..."}
    </div>
  );
}
