import { WORKPLACE_KNOWLEDGE_BASE, type KnowledgeEntry } from "@/data/workplaceKnowledgeBase";

export const WORKPLACE_KNOWLEDGE_TOOL_NAME = "Workplace Knowledge Tool";

/** Searches the Workplace Knowledge Base by keyword relevance. */
export function searchWorkplaceKnowledge(query: string): KnowledgeEntry[] {
  const q = query.toLowerCase();
  return WORKPLACE_KNOWLEDGE_BASE.map((entry) => ({
    entry,
    score: entry.keywords.reduce((s, k) => (q.includes(k) ? s + k.length : s), 0),
  }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((r) => r.entry);
}
