// Workplace Knowledge Base — fictional demonstration data only.
export interface KnowledgeEntry {
  id: string;
  title: string;
  keywords: string[];
  content: string;
}

export const WORKPLACE_KNOWLEDGE_BASE: KnowledgeEntry[] = [
  {
    id: "wfh",
    title: "Work From Home Policy",
    keywords: ["work from home", "wfh", "remote", "home", "hybrid", "telework"],
    content: "Employees may work from home up to 2 days per week with manager approval.",
  },
  {
    id: "hours",
    title: "Office Working Hours",
    keywords: ["hours", "working hours", "office hours", "timing", "schedule", "time", "open"],
    content: "Regular office hours are 9:00 AM to 6:00 PM, Monday to Friday.",
  },
  {
    id: "leave",
    title: "Leave Policy",
    keywords: ["leave", "vacation", "time off", "holiday", "absence", "pto"],
    content:
      "Employees should submit planned leave at least 2 working days in advance. Leave requests are subject to manager approval and applicable leave balance.",
  },
  {
    id: "benefits",
    title: "Employee Benefits",
    keywords: ["benefits", "insurance", "health", "perks", "learning", "development", "training"],
    content:
      "Employees may receive health insurance, paid leave and learning/development benefits according to company policy.",
  },
  {
    id: "guidelines",
    title: "General Workplace Guidelines",
    keywords: ["guidelines", "conduct", "safety", "security", "attendance", "rules", "behaviour", "behavior"],
    content:
      "Employees should follow workplace safety, security, attendance and professional conduct guidelines.",
  },
];
