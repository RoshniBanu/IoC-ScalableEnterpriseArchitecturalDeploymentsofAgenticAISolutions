<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Exactly one agent (`src/agent/officeAssistAgent.server.ts`), one tool (`src/tools/workplaceKnowledgeTool.ts`), one knowledge base (`src/data/`) — the app demonstrates single-agent tool use.
- Agent runs server-side via `src/services/agent.functions.ts` so the AI key and prompt never reach the browser.
- Monitoring metrics are browser-local demo telemetry (`src/services/telemetry.ts`); no database by design.
